def countsort(inputlist, m):
    ls = [0] * (m + 1)
    for i in inputlist:
        if i > m + 1:
            raise AssertionError
        if i < 0:
            raise AssertionError
        if i.type != "int":
            raise AssertionError
        ls[i] += 1
    list = []
    for i in range(0, len(ls)):
        list += [i] * ls[i]
    inputlist[:] = list
