'''
   1  2  3  4  5  6  7  8  9
1 [+][ ][ ][ ][ ][ ][ ][ ][ ] @: You
2 [+][ ][.][ ][ ][ ][ ][ ][ ] +: Explored room
3 [+][ ][.][.][.][ ][ ][ ][ ] .: Unexplored room
4 [+][@][.][ ][ ][ ][ ][ ][ ]     N
5 [ ][ ][.][ ][ ][ ][ ][ ][ ]   W + E
6 [ ][ ][ ][ ][ ][ ][ ][ ][ ]     S
7 [ ][ ][ ][ ][ ][ ][ ][ ][ ]
8 [ ][ ][ ][ ][ ][ ][ ][ ][ ]
9 [ ][ ][ ][ ][ ][ ][ ][ ][ ]
'''
import os
from room import Room


def showMap(manual = 1):
    if manual == 1: #Allows for displaying the map on screens other than the map screen.
        os.system('cls' if os.name == 'nt' else 'clear')
    else:
        print()
    print("   1  2  3  4  5") #The "explored" variable should be a string.
    print("1 [" + str(OneOne.explored) + "][" + str(TwoOne.explored) + "][" + str(ThreeOne.explored) + "][" + str(FourOne.explored) + "][" + str(FiveOne.explored) + "] @: You")
    print("2 [" + str(OneTwo.explored) + "][" + str(TwoTwo.explored) + "][" + str(ThreeTwo.explored) + "][" + str(FourTwo.explored) + "][" + str(FiveTwo.explored) + "] +: Explored room")
    print("3 [" + str(OneThree.explored) + "][" + str(TwoThree.explored) + "][" + str(ThreeThree.explored) + "][" + str(FourThree.explored) + "][" + str(FiveThree.explored) + "] .: Unexplored room")
    print("4 [" + str(OneFour.explored) + "][" + str(TwoFour.explored) + "][" + str(ThreeFour.explored) + "][" + str(FourFour.explored) + "][" + str(FiveFour.explored) + "]      N")
    print("5 [" + str(OneFive.explored) + "][" + str(TwoFive.explored) + "][" + str(ThreeFive.explored) + "][" + str(FourFive.explored) + "][" + str(FiveFive.explored) + "]   W + E")
    print("6 [" + str(OneSix.explored) + "][" + str(TwoSix.explored) + "][" + str(ThreeSix.explored) + "][" + str(FourSix.explored) + "][" + str(FiveSix.explored) + "]     S")
    print()
    if manual == 1:
        input("Press enter to continue...")


#Rooms should have a few self variables.
#Explored, which is used for the player's map.
#Contents, which denotes the type of room ([P]uzzle, [M]onster, [T]reasure). (Monster rooms can contain treasure as well, but treasure rooms are dediceated to it.)
