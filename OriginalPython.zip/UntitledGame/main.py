from room import Room
from player import Player
from item import Item
from monster import Monster
import os
import updater
#import map
import random
#from roomMaker import RoomMaker

player = Player()
''' Original code
def createWorld():
    a = Room("You are in room 1", "monster")
    b = Room("You are in room 2", "puzzle")
    c = Room("You are in room 3", "monster")
    d = Room("You are in room 4", "monster")
    Room.connectRooms(a, "east", b, "west")
    Room.connectRooms(c, "east", d, "west")
    Room.connectRooms(a, "north", c, "south")
    Room.connectRooms(b, "north", d, "south")
    i = Item("Rock", "This is just a rock.")
    i.putInRoom(b)
    player.location = a
    a.explored = "@"
    Monster("Bob the monster", 20, b)
'''

class World():
    def createDungeonOne(self):
        self.OneOne, self.TwoOne, self.ThreeOne, self.FourOne, self.FiveOne = Room(r.dungeonThreePredetermined[1], "Empty"), Room(r.dungeonThreePredetermined[4], "Empty"), Room(r.dungeonStandard[10], "Monster"), Room(r.dungeonStandard[7], "Monster"), Room(r.dungeonTwoPredetermined[3], "Item", 0, 1)
        self.OneTwo, self.TwoTwo, self.ThreeTwo, self.FourTwo, self.FiveTwo = Room(r.dungeonThreePredetermined[2], "Item"), Room(r.dungeonStandard[11], "Monster"), Room(r.dungeonStandard[8], "Monster"), Room(r.dungeonStandard[6], "Monster"), Room(r.dungeonStandard[5], "Monster")
        self.OneThree, self.TwoThree, self.ThreeThree, self.FourThree, self.FiveThree = Room(r.dungeonThreePredetermined[3], "Door"), Room(r.dungeonStandard[9], "Monster"), Room(r.dungeonThreePredetermined[0], "Shop", 0, 1, 1), Room(r.dungeonTwoPredetermined[4], "Monster"), Room(r.dungeonStandard[4], "Monster")
        self.OneFour, self.TwoFour, self.ThreeFour, self.FourFour, self.FiveFour = Room(r.dungeonOneAnnoyance[0], "Annoyance"), Room(r.dungeonOnePredetermined[2], "Boss", 0, 1), Room(r.dungeonOneAnnoyance[1], "annoyance"), Room(r.dungeonTwoPredetermined[2], "Item", 0, 1), Room(r.dungeonStandard[2], "Monster")
        self.OneFive, self.TwoFive, self.ThreeFive, self.FourFive, self.FiveFive = Room(r.dungeonOnePuzzle[0], "Puzzle", 1), Room(r.dungeonOnePredetermined[3], "Item"), Room(r.dungeonOnePuzzle[1], "Puzzle", 1), Room(r.dungeonStandard[1], "Monster"), Room(r.dungeonStandard[3], "Monster")
        self.OneSix, self.TwoSix, self.ThreeSix, self.FourSix, self.FiveSix = Room(r.dungeonStandard[0], "Monster"), Room(r.dungeonOnePredetermined[0], "Entrance"), Room(r.dungeonOnePredetermined[1], "Monster"), Room(r.dungeonTwoPredetermined[0], "Shop", 0, 0, 0, 1), Room(r.dungeonTwoPredetermined[1], "Item", 0, 1)
        self.Exit = Room("You are victorious! Thankfully, your changes begin to reverse as soon as you exit the dungeon.", "Exit") #Exit room
        self.Secret = Room("This is the secret ending!\nI have an interesting ending planned to go here, but since I'm so close to the deadline, I'm going to take inspiration from the PC games of the 90's and leave this as an incredibly unsatisfying ending.", "Secret") #Secret room
        Room.connectRooms(self.OneSix, "east", self.TwoSix, "west")
        Room.connectRooms(self.ThreeSix, "west", self.TwoSix, "east")
        Room.connectRooms(self.OneSix, "north", self.OneFive, "south")
        Room.connectRooms(self.ThreeSix, "north", self.ThreeFive, "south")
        Room.connectRooms(self.FourSix, "north", self.FourFive, "south")
        Room.connectRooms(self.FourFive, "east", self.FiveFive, "west")
        Room.connectRooms(self.FiveFive, "south", self.FiveSix, "north")
        Room.connectRooms(self.FiveFive, "north", self.FiveFour, "south")
        Room.connectRooms(self.FiveFour, "north", self.FiveThree, "south")
        Room.connectRooms(self.FiveThree, "north", self.FiveTwo, "south")
        Room.connectRooms(self.FourTwo, "east", self.FiveTwo, "west")
        Room.connectRooms(self.FourOne, "east", self.FiveOne, "west")
        Room.connectRooms(self.FourOne, "south", self.FourTwo, "north")
        Room.connectRooms(self.FourTwo, "south", self.FourThree, "north")
        Room.connectRooms(self.FourThree, "south", self.FourFour, "north")
        Room.connectRooms(self.TwoThree, "east", self.ThreeThree, "west")
        Room.connectRooms(self.TwoTwo, "east", self.ThreeTwo, "west")
        Room.connectRooms(self.TwoOne, "east", self.ThreeOne, "west")
        Room.connectRooms(self.OneOne, "east", self.TwoOne, "west")
        Room.connectRooms(self.TwoTwo, "south", self.TwoThree, "north")
        Room.connectRooms(self.ThreeOne, "south", self.ThreeTwo, "north")
        Room.connectRooms(self.Exit, "south", self.TwoOne, "north")
        Room.connectRooms(self.OneOne, "south", self.OneTwo, "north")
        Room.connectRooms(self.OneTwo, "south", self.OneThree, "north")
        if self.OneFour.desc == "\'tis a dead end.":
            Room.connectRooms(self.TwoFour, "east", self.ThreeFour, "west")
        else:
            Room.connectRooms(self.OneFour, "east", self.TwoFour, "west")
        Monster(m.dungoenOneMonsterList[0], 20, self.OneSix)
        Monster(m.dungoenOneMonsterList[1], 20, self.ThreeSix)
        Monster("Omnivorous plant", 30, self.TwoFour)
        #i = Item("Rock", "This is just a rock.", 0, [0]) #Currently not random.
        #x = Item("Tiny healing potion", "This potion is almost useless. 1 point of health? Seriously?", 4, [1, 1])
        potion1 = Item("Health potion", "This potion should heal about 10 points of health.\n\"Should\" is the key word there.", 0, [1, 10])
        potion2 = Item("Health potion", "This potion should heal about 10 points of health.\n\"Should\" is the key word there.", 0, [1, 10])
        potionBoss = Item("Health potion", "This potion should heal about 10 points of health.\n\"Should\" is the key word there.", 0, [1, 10])
        currency1 = Item("Coins", "A few coins.", 3, [4, 3])
        currency2 = Item("Coins", "A few coins.", 7, [4, 7])
        currencyBoss = Item("Coins", "10 coins!", 10, [4, 10])
        currency1.putInRoom(self.OneSix)
        currency2.putInRoom(self.ThreeSix)
        currencyBoss.putInRoom(self.TwoFour)
        potion1.putInRoom(self.OneFive)
        potion2.putInRoom(self.ThreeFive)
        self.doorKey = Item("Door key", "This key has a label on it that says \"(3,6).\"", 0, [5, 0])
        self.zone2Key1 = Item("Key part 1", "A peice of a key.", 0, [5, 1])
        self.zone2Key2 = Item("Key part 2", "A peice of a key.", 0, [5, 1])
        self.zone2Key3 = Item("Key part 3", "A peice of a key.", 0, [5, 1])
        self.secretKey1 = Item("Mysterious key", "Where does this go?", 0, [5, 2])
        self.secretKey2 = Item("Unusual key", "What secrets could this unlock?", 0, [5, 2])
        self.secretKey3 = Item("Strange key", "When will you use this?", 0, [5, 2])
        self.glowKey = Item("Glowing key", "This key is emitting a purple-ish glow.", 0, [5, 3])
        self.doorKey.putInRoom(self.TwoFour)
        potionBoss.putInRoom(self.TwoFour)
        self.zone2Key1.putInRoom(self.FourFour)
        self.zone2Key2.putInRoom(self.FiveSix)
        self.zone2Key3.putInRoom(self.FiveOne)
        self.secretKey1.putInRoom(self.TwoFive)
        self.secretKey2.putInRoom(self.ThreeThree)
        self.glowKey.putInRoom(self.OneTwo)
        potion3 = Item("Health potion", "This potion should heal about 10 points of health.\n\"Should\" is the key word there.", 0, [1, 10])
        potion4 = Item("Health potion", "This potion should heal about 10 points of health.\n\"Should\" is the key word there.", 0, [1, 10])
        potion5 = Item("Health potion", "This potion should heal about 10 points of health.\n\"Should\" is the key word there.", 0, [1, 10])
        coins1 = Item("Coins", "A few coins.", 2, [4, 2])
        coins2 = Item("Coins", "A few coins.", 8, [4, 8])
        coins3 = Item("Coins", "12 coins!", 12, [4, 12])
        coins4 = Item("Coins", "A few coins.", 4, [4, 4])
        coins5 = Item("Coins", "A few coins.", 6, [4, 6])
        coins6 = Item("Coins", "8 coins.", 8, [4, 8])
        self.itemDrops = [coins1, coins2, coins3, coins4, coins5, coins6, potion3, potion4, potion5] #Random loot
        random.shuffle(self.itemDrops)
        self.itemDrops[0].putInRoom(self.FourFive)
        self.itemDrops[1].putInRoom(self.FiveFive)
        self.itemDrops[2].putInRoom(self.FiveThree)
        self.itemDrops[3].putInRoom(self.FourThree)
        self.itemDrops[4].putInRoom(self.ThreeTwo)
        self.itemDrops[5].putInRoom(self.FiveTwo)
        self.itemDrops[6].putInRoom(self.FourOne)
        self.itemDrops[7].putInRoom(self.FourOne)
        self.itemDrops[8].putInRoom(self.FiveFive)
        potion6 = Item("Health potion", "This potion should heal about 10 points of health.\n\"Should\" is the key word there.", 0, [1, 10])
        potion6.putInRoom(self.FourTwo)
        Monster(m.monsterTwo[0], 11, self.FourFive)
        Monster(m.monsterTwo[1], 13, self.FiveFive)
        Monster(m.monsterTwo[2], 8, self.FiveFour)
        Monster(m.monsterTwo[3], 13, self.FourThree)
        Monster(m.monsterTwo[4], 18, self.FiveThree)
        Monster(m.monsterTwo[5], 13, self.FiveTwo)
        Monster(m.monsterTwo[6], 15, self.FourTwo)
        Monster(m.monsterTwo[7], 13, self.FourOne)
        self.secretKey3.putInRoom(self.FourSix) #This key goes in the store.
        armor = Item("Armor", "This set of armor should provide some protection against the mosnters you will need to face in order to escape.", 10, [3, 5])
        sword = Item("Sword", "This sword should provide some protection against the mosnters you will need to face in order to escape.", 5, [2, 3])
        armor.putInRoom(self.FourSix)
        sword.putInRoom(self.FourSix)
        player.location = self.TwoSix
        self.TwoSix.explored = "@"

class MonsterMaker(): #Generates the monsters for each part of the dungeon
    def __init__(self):
        self.dungoenOneMonsterList = ["Whenwolf", "Floating orb"]
        random.shuffle(self.dungoenOneMonsterList)
        self.monsterTwo = ["Obligatory giant rat", "Regular sized rat", "The Wearwolf", "Largo-morph", "The Wearwolf's favorite dress", "Presto-morph", "Snow Leopard Shark", "Mer-owl"]
        random.shuffle(self.monsterTwo)

class RoomMaker:
    def __init__(self):
        self.dialTurns = random.randint(1200, 1700)
        self.dialOneMaxNumber = random.randint(4,9)
        self.dialTwoMaxNumber = random.randint(4,9)
        while self.dialTwoMaxNumber == self.dialOneMaxNumber:
            self.dialTwoMaxNumber = random.randint(4,9)

        self.dungeonStandard = ["As far as architecture goes, this room has basically no defining features. It's somehow blander than an expired matzah cracker.", "Stepping into the room, it's clear that this room is part of the dungeon's sewer system. You start to wonder how exactly that works in a constantly shifting labyrinth, but then you remember that a magical curse is the whole reason you're in this mess. There's no point in trying to figure out how magic sewer systems work right now, you're on a strict time limit. Nevertheless, your internal counter for how many times you've been forced to explore a sewer ticks up by one.", "The massive stone walls in this room seem to stretch up forever.", "There is an etching on the floor of this room. It reads \"This room doesn't contain any traps, but you need to stay on your toes for when one does!\"", "Each of the four walls of this room feature what appears to be an intricate stained glass window. Light pours into the room from each of them, projecting their designs onto the floor, but upon closer inspection, the windows are actually emitting their own light, and there is no way to break through them and enter into another room.", "This is the dungeon's kitchen. It's remarkably clean, surprisingly.", "This room appears to be a barracks of some sort, with beds lining the walls. Do the monsters all sleep here?", "This room appears to be a dressing room and a green room, like you would see at a theater.\nThs must be where the monsters get their hair and makeup done before you encounter them.", "This room is in utter disarray. \nYou really should avoid stepping on the broken bits of ceramic on the ground. \nThose are quite sharp!", "If this room had a middle name, it would be \"Clutter.\" Unfortunately, none of the clutter looks like it will be very helpful in getting you out of here.", "Hopefully this room is close to the exit.", "The room is incredibly dark. Soemhow, the light from the adjacent rooms is barely entering into this one.\nIt's probably due to magic or something like that. Hopefully there isn't anything dangerous in this room, becausse it's really hard to see much here.", "This room's walls have all been painted maroon."]
        random.shuffle(self.dungeonStandard)
        self.dungeonOnePuzzle = ["A stone pedestal stands in the center of this room. On it are two dials. The first has notches numbered 0-" + str(self.dialOneMaxNumber - 1) + ", \nand the second has the numbers 0-" + str(self.dialTwoMaxNumber - 1) +". \nA note next to them reads 'Starting with both dials set to 0, just turn each one " + str(self.dialTurns) + " notches, and you'll be out of here in no time.\n \nIn a room containing a puzzle, you can attempt to solve it by typing 'puzzle.'", "A strange creature sits in the center of the room.\n\"Before you try to attack me, think about what you'd need in order to do so,\" they say.\n\"Yep, in order to attack me, you'd need to type out my full name in order to use the attack command. So, how about this? If you can guess my name, I'll leave without a fight. If not, you'll be stuck here until that curse of yours has run its course. I'll give you some hints as you guess though.\"\nType \"puzzle\" to begin guessing."]
        random.shuffle(self.dungeonOnePuzzle)
        self.dungeonOnePredetermined = ["The gate closed as you entered the dungeon. There's no going back now.", "There's a door to the east, but it appears to be locked.\nOnce you have the key required to open this door, simply use the \"unlock\" command to open it!", "This room seems to be a greenhouse. A sign near where you entered from reads \"DO NOT FEED THE PLANTS.\"\nOh, and a very threatening looking plant. You might want to use a health potion or something.\nThere's also a strange stone door here. If you find a key, maybe it would unlock it!", "Oooh, a chest! What secrets could it hold?"]
        self.dungeonOneAnnoyance = ["\'tis a dead end.", "Oh, good. You're glad that completing that puzzle is leading to somewhere useful instead of just a dead end or something. It would be extremely frustrating if a puzzle like that didn't lead to meaningful progression through the dungeon."]
        random.shuffle(self.dungeonOneAnnoyance)
        self.dungeonTwoPredetermined = ["A ghostly figure greets you as you enter the room. \"Hello! Welcome to my shop! I'm Ogollo, the largest supplier of adventuring goods and services in pocket dimension dungeons! I don't have much availible for you in this shop, due to the limitations the owner of this dungeon has placed on me, but you can be sure that if it weren't for the rules of this game, you'd have a larger selection of armors and potions availible to you in one of my shops than you would find in any other shop across the many worlds I offer my services on.\nAs for right now, my inventory has been artificailly limited to a single 5 coin sword and a set of 10 coin armor tailored for someone of your current condition. I can assure you that, even as your body changes, this armor will continue to fit well. Since it's your first time seeing me, I can also offer to fully restore your health for just 5 coins.\nOh, and I also have this strange key for you, but I'm not quite sure what it unlocks. That one's free, courtesy of the dungeon's owner. I thought it might unlock the chest that they put in the other room they let me set up shop in, but it doesn't seem to fit.\nSo, what would you like to buy?\"", "The main feature in this room is definitely the chest in the center of the room.", "This room is defined by the chest sitting off in its corner.", "Finally! Another chest.", "There is a locked door to the west."]
        self.dungeonThreePredetermined = ["It's Ogollo again! It looks like this stall has different items, but one item stands out. Ogollo is intently examining a glowing purple chest. This must be the chest that he thought the strange key might fit.\n\"Oh, It's you again! I don't think you actually want to buy anything from me right now, but if you find the key to this chest, definitely bring it back here!", "You can't quite figure out what this room's purpose is.", "It's faint, but the walls of this room are emitting purple light.", "A large, ominous door stands before you. There are three slots for keys next to the door, which are shaped like the key that Ogollo offered to you.\nWhat secrets could be hidden behind it?\nDo you even have time to find out?", "At last! The exit to the dungeon is just to the north of here!"]
    def dungeonOneDialPuzzle(self):
        hints = 0 #Hint system for struggling players
        while True:
            if hints == 2:
                print("\nHere's a hint: When a 0-3 dial set to 3 is turned one notch more, it is then set to 0.")
            if hints == 3:
                print("\nHere's another hint: Modulo is very useful here!")
            if hints == 4:
                print("\nOne more hint: A dial numbered 0-3 has four notches on it.")
            if hints == 5:
                print("\nOne last hint: Notches to turn dial % number of notches on dial = correct setting for that dial")
            print()
            print("What position do you set the first dial to?")
            try:
                d1 = int(input())
                print("How about the second one?")
                d2 = int(input())
                if d1 == self.dialTurns % self.dialOneMaxNumber and d2 == self.dialTurns % self.dialTwoMaxNumber:
                    print("The two dials click into place, as the walls in front of you open to reveal a new exit.")
                    player.location.puzzleState = 0
                    unlock()
                    player.location.desc = "You've solved the puzzle in this room!"
                    input("Press enter to continue...")
                    if hints != 0:
                        timePassing(hints)
                    break
                elif player.cheating == 1:
                    print("Cheater! I can't blame you though. The solution is random, so it's a lot easier to just cheat on repeat playthroughs.")
                    player.location.puzzleState = 0
                    unlock()
                    player.location.desc = "You may not have solved the puzzle, but at least you can continue."
                    input("Press enter to continue...")
                    if hints != 0:
                        timePassing(hints)
                    break
                elif hints == 5:
                    print("Eventually, you decided to just solve the puzzle by brute forcing it.\nThankfully, trying every combination didn't really take very long.")
                    print("The two dials click into place, as the walls in front of you open to reveal a new exit.")
                    player.location.puzzleState = 0
                    unlock()
                    player.location.desc = "You've solved the puzzle in this room!"
                    input("Press enter to continue...")
                    timePassing(7)
                elif d1 == "etc." or d1 == "etc" or d2 == "etc" or d2 == "etc.":
                    print("No, \"etc.\" isn't an arabic numeral.\n")
                    print("Ugh, just go, the door is unlocked.")
                    player.location.puzzleState = 0
                    unlock()
                    player.location.desc = "You may not have solved the puzzle, but at least you can continue."
                    input("Press enter to continue...")
                    if hints != 0:
                        timePassing(hints)
                    break
                else:
                    print("You've spent some time attempting the puzzle, but it doesn't seem like you have the solution.")
                    hints += 1
            except:
                print("Please type your answers using arabic numerals. (1, 2, 3, etc.)")
    def NamePuzzle(self):
        hints = 0
        while True:
            clear()
            print("The creature repeats their challenge once again.")
            if hints == 0:
                print("\"All you need to do is guess my name. Your only hint for now is that it'll be useful to think backwards.\"")
            else:
                print("\"Remember, all you need to do is guess my name. It'll be useful to think backwards.\"")
            if hints >= 2:
                print("\"Have you ever heard a story where someone receives a similar challenge?\"")
            if hints >= 3:
                print("\"I'm basically the opposite of the character from that story.\"")
            if hints >= 4:
                print("\"This puzzle is from Roberta Williams's \"King's Quest,\" and it's infamous for its difficulty.\"")
            if hints >= 5:
                print("\"It might be useful to Google this puzzle.\"")
            if hints >= 5:
                print("\"Here's another hint: Call Sierra's hint line! It's only $0.95 per 30 seconds. You must be 18 or older to call.\"")
                print("Don't actually do that.")
            guess = input("\"So, what do you think my name is?\"\n")
            if guess.lower() == "ifnkovhgroghprm":
                print("\"Goodness, no. I don't need to sell you a hint guide that badly. You're very close though!\"")
                print()
                hints += 1
                input("Press enter to try again...")
                timePassing()
            elif guess.lower() == "rumplestiltskin" or guess.lower() == "rumpelstiltskin": #King's Quest used a weird spelling.
                print("\"It's not quite that easy, but you're on the right track!\nThink about the first hint I gave you!\"")
                print()
                hints += 1
                input("Press enter to try again...")
                timePassing()
            elif guess.lower() == "nikstlitselpmur" or guess.lower() == "nikstlitslepmur":
                if hints == 0:
                    print("\"Wow, looks like someone has played this game before!\" they exclaim as they disappear through the newly opened door to the north.")
                else:
                    print("\"That's it! Hopefully you still have enough time to escape, haha,\" they say, disappearing through the newly opened door to the north.")
                player.location.puzzleState = 0
                unlock()
                player.location.desc = "You've solved the puzzle in this room!"
                input("Press enter to continue...")
                break
            elif player.cheating == 1:
                print("\"Oh, sorry, I didn't realize you were a cheater until now. I'll be on my way then. See you later!\"")
                player.location.puzzleState = 0
                unlock()
                player.location.desc = "You cheated. Are you proud of yourself?"
                input("Press enter to continue...")
                timePassing(hints)
                break
            elif random.random() < .2:
                print("\"Really? No. What sort of name is that?\"")
                print()
                hints += 1
                timePassing()
                input("Press enter to try again...")
            else:
                print("\"Nope, that's not my name.\"")
                print()
                hints += 1
                input("Press enter to try again...")
                timePassing()
    def puzzlePicker(self): #What puzzle is in this room?
        if player.location.desc[:16] == "A stone pedestal":
            self.dungeonOneDialPuzzle()
        elif player.location.desc[:9] == "A strange":
            self.NamePuzzle()
        else:
            print("There's no puzzle in this room.")
            print()
            input("Press enter to continue...")

def timePassing(units = 1): #Controls passage of time and curse progression.
    for i in range(0, units):
        updater.updateAll()
        if inDungeon == True:
            player.timeSpent += 1
            if player.timeSpent % 10 == 1:
                player.curseStage = player.timeSpent // 10 #Events that occur over time.
                clear()
                player.conditions.append(player.curseconditions[player.curseStage])
                if player.curseStage == 1: #The player is no longer unchanged.
                    player.conditions = [player.curseconditions[player.curseStage]]
                elif player.curseStage == 5: #The player has paws and cannot equip weapons
                    player.bonusAttack = 1 #Claws on paws
                print(player.curseEvents[player.curseStage])
                print()
                input("Press enter to continue...")
                player.showMe()
            if player.timeSpent > 80:
                player.fullyTransformed()
            if player.health < 50 and player.timeSpent % 2 == 0: #As the player's body reconstructs itself due to the curse, thier wounds heal slowly.
                player.health += 1

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')


def printSituation():
    clear()
    if player.resume == True:
        print("Okay, let's get back to what we were doing.") #If the player just tried to do something that doesn't happen in the game's world, (such as using the "quit" command) then this message displays before the description.
        print()
        player.resume = False
    print(player.location.desc)
    print()
    roomcleared = player.location.puzzleState
    if player.location.hasMonsters():
        print("This room contains the following monsters:")
        for m in player.location.monsters:
            print(m.name)
        print()
        roomcleared += 1
    elif player.location.hasItems():
        if player.location.chestState == 0:
            if player.location.secret == 0:
                if player.location.type.lower() != "monster":
                    print("This room contains the following items:")
                else:
                    print("The monster left an item behind!")
                for i in player.location.items:
                    print(i.name)
                print()
                roomcleared += 1
            else:
                print("The chest is locked tight. Unlocking it will require a key.")
        else:
            print("This room contains the following items:")
            print("There is a chest here! Open it and find out what it contains!")
            print()
    if roomcleared == 0: #If the room is cleared, show the player the map
        showMap(0)
    print("You can go in the following directions:")
    for e in player.location.exitNames():
        print(e)
    print()

def showHelp(): #Note to self: Don't forget to update this!
    clear()
    print("go <direction> -- Moves you in the given direction")
    print("inventory -- Opens your inventory")
    print("get <item> -- Picks up the item")
    print("use <item> -- Uses the item")
    print("me -- Examine yourself")
    print("open -- Opens any chests in the room")
    print("unlock -- Unlocks anything that is locked in the room, provided you have the required key")
    print("buy <item> -- Purchase items from shops")
    print("attack <monster's name> -- Fight a monster")
    print("examine <object> -- Look at any object in your vicinity or inventory")
    print("puzzle -- In a room containing a puzzle, ")
    print()
    input("To see more commands, press enter.")
    clear()
    print("map -- View a map of the current dungeon")
    print("retreat -- Return to the previous room")
    print("wait <number of turns to wait (optional)> -- Waste precious time")
    print("history <on or off> -- Choose whether or not the screen is cleared after most actions")
    print("n, s, e, or w -- Travel shortcut to use instead of 'go'")
    print("i -- Inventory shortcut")
    print("x -- Examine shortcut")
    print("u -- Use shortcut")
    print("quit -- Quits the game")
    print()
    input("To return to the game, press enter.")

def save(): #Saving would have occured inbetween dungeons, recording this information as a password: What curse the player has, how many turns they have spent, how much money their current possessions are worth, and thier story progression.
    clear() #If I add more curses, change the first digit to represent the player's curse.
    if player.curse and player.timeSpent and player.money and player.progression:
        savestring = "1" + (3 - len(player.timeSpent)) * "0" + str(player.timeSpent) + (3 - len(player.money)) * "0" + str(player.money) + (4 - len(player.experience)) * "0" + str(player.experience) + str(player.progression)
        stringsum = 0
        for i in savestring:
            stringsum += int(i)
        savestring += str(2000 - stringsum) #CHANGE 2000 to a higher value
    print("Password: " + savestring)
    print()
    input("Press enter to continue...")

def load(password): #The other half of saving and loading.
    clear()
    totalsum = 0
    for i in password:
        totalsum += int(i)
    if totalsum == 2000:
        player = Player(password[0], password[1:3], password[4:6], password[7:10], password[11]) #Curse, timeSpent, money, experience, progression
    else:
        print("Invalid password.")
        player = Player()
#SHOWMAP
def showMap(manual = 1):
    if manual == 1: #Allows for displaying the map on screens other than the map screen.
        os.system('cls' if os.name == 'nt' else 'clear')
    print("   1  2  3  4  5") #The "explored" variable should be a string.
    print("1 [" + str(w.OneOne.explored) + "][" + str(w.TwoOne.explored) + "][" + str(w.ThreeOne.explored) + "][" + str(w.FourOne.explored) + "][" + str(w.FiveOne.explored) + "] @: You")
    print("2 [" + str(w.OneTwo.explored) + "][" + str(w.TwoTwo.explored) + "][" + str(w.ThreeTwo.explored) + "][" + str(w.FourTwo.explored) + "][" + str(w.FiveTwo.explored) + "] +: Explored room")
    print("3 [" + str(w.OneThree.explored) + "][" + str(w.TwoThree.explored) + "][" + str(w.ThreeThree.explored) + "][" + str(w.FourThree.explored) + "][" + str(w.FiveThree.explored) + "] .: Unexplored room")
    print("4 [" + str(w.OneFour.explored) + "][" + str(w.TwoFour.explored) + "][" + str(w.ThreeFour.explored) + "][" + str(w.FourFour.explored) + "][" + str(w.FiveFour.explored) + "]     N")
    print("5 [" + str(w.OneFive.explored) + "][" + str(w.TwoFive.explored) + "][" + str(w.ThreeFive.explored) + "][" + str(w.FourFive.explored) + "][" + str(w.FiveFive.explored) + "]   W + E")
    print("6 [" + str(w.OneSix.explored) + "][" + str(w.TwoSix.explored) + "][" + str(w.ThreeSix.explored) + "][" + str(w.FourSix.explored) + "][" + str(w.FiveSix.explored) + "]     S")
    print()
    if manual == 1:
        input("Press enter to continue...")

def useItem(item):
    if item.effect[0] == 0: #No effect
        clear()
        print("You can't use that item, unfortunately.")
        print("Wouldn't it be neat if you could though?\n")
        input("Press enter to continue...")
    elif item.effect[0] == 1: #Healing potion
        player.health += item.effect[1]
        clear()
        print("You quaff the potion, and its effects immediately begin to flow through your body.")
        print("Health +" + str(item.effect[1]))
        try:
            player.location.removeItem(item)
        except:
            player.items.remove(item)
        print()
        input("Press enter to continue...")
    elif item.effect[0] == 2: #weapon
        if player.bonusAttack != 1: #This value is only 1 if the player has paws and cannot equip weapons.
            clear()
            player.bonusAttack = item.effect[1]
            print("Your attack bonus is now " + str(player.bonusAttack) + "!")
            print("Sweet!")
            print()
            input("Press enter to continue...")
        else:
            clear()
            print("The weapon falls to the floor as your clumsy paws fail to grasp it.")
            print()
            input("Press enter to continue...")
    elif item.effect[0] == 3: #Armor
        clear()
        player.armorRating = item.effect[1]
        print("Your defense rating is now " + str(player.armorRating) + "!")
        print("Excelent!")
        print()
        input("Press enter to continue...")
    elif item.effect[0] == 4: #money
        clear()
        player.money += item.effect[1]
        print("You pick up " + str(item.effect[1]) + " coins.")
        print("You now have " + str(player.money) + " coins.")
        print()
        input("Press enter to continue...")
        try:
            player.location.removeItem(item)
        except:
            player.items.remove(player.getItemByName(item))


def unlock(): #This function handles unlocking new rooms, wether that's through puzzles or the use of keys.
    if player.location == w.OneFive:
        if player.location.puzzleState == 0:
            Room.connectRooms(w.OneFive, "north", w.OneFour, "south")
        else:
            clear()
            print("Unless you have a key somewhere that I don't know about, you're going to need to complete that puzzle.")
            print("I mean, even if you did have a key, I don't think that there is anywhere to put it.")
            print()
            input("Press enter to continue...")
    elif player.location == w.ThreeFive:
        if player.location.puzzleState == 0:
            Room.connectRooms(w.ThreeFive, "north", w.ThreeFour, "south")
        else:
            clear()
            print("Unless you have a key somewhere that I don't know about, you're going to need to complete that puzzle.")
            print("I mean, even if you did have a key, I don't think that there's anywhere for you to put it.")
            print()
            input("Press enter to continue...")
    elif player.location == w.ThreeSix:
        if player.getItemByName("Door key") == w.doorKey or player.cheating == 1:
            Room.connectRooms(w.ThreeSix, "east", w.FourSix, "west")
        else:
            clear()
            print("You don't have the key for this door yet.")
            print()
            input("Press enter to continue...")
    elif player.location == w.FourThree:
        if player.getItemByName("Key part 1") == w.zone2Key1 and player.getItemByName("Key part 2") == w.zone2Key2 and player.getItemByName("Key part 3") == w.zone2Key3 or player.cheating == 1:
            Room.connectRooms(w.ThreeThree, "east", w.FourThree, "west")
        else:
            clear()
            print("You don't have all three parts of the key yet.")
            print()
            input("Press enter to continue...")
    elif player.location == w.OneThree:
        if player.getItemByName("Strange key") == w.secretKey3 and player.getItemByName("Unusual key") == w.secretKey2 and player.getItemByName("Mysterious key") == w.secretKey1 or player.cheating == 1:
            Room.connectRooms(w.OneThree, "west", w.Secret, "east")
            w.OneThree.desc = "It's time to find out what's really going on here."
        else:
            clear()
            print("You need all three keys before you can open this door!.")
            print()
            input("Press enter to continue...")
    elif player.location == w.TwoFour:
        if player.getItemByName("Strange key") == w.secretKey3 or player.getItemByName("Unusual key") == w.secretKey2 or player.getItemByName("Mysterious key") == w.secretKey1 or player.cheating == 1:
            Room.connectRooms(w.TwoFour, "south", w.TwoFive, "north")
        else:
            clear()
            print("That key doesn't fit in this door. Maybe it fits somewhere else?")
            print()
            input("Press enter to continue...")
    elif player.location == w.ThreeThree:
        if player.getItemByName("glowing key") == w.glowKey or player.cheating == 1:
            player.location.secret = 0
            finalBoss = Monster("Final boss", 45, w.OneOne)
            w.OneOne.desc = "Now it's obvious!"
            print("With a click, the chest unlocks. Open it and find out what's inside!")
            print()
            input("Press enter to continue...")
    else:
        print("I could be wrong, but I don't think that there's anything to unlock here.")
        print("Nope, I just checked. There's definitely nothing here to unlock. Sorry.")
        print()
        input("Press enter to continue...")

def introduction():
    clear()
    print("TITLE GOES HERE\n\nSnepShark")
    print()
    input("Press enter to continue...")
    clear()
    print("\"Wake up! You don't have much time!\" \nA woman violently wakes you from your sleep, shaking you as they speak in an urgent tone.")
    print()
    input("Press enter to continue...")
    clear()
    print("The cold, rough, stone floor of the dimly lit room you find yourself in isn't a terribly cofortable place to rest, so it'd be pretty difficult to fall back asleep now.")
    print()
    input("Press enter to continue...")
    clear()
    print("\"I've already read the instructions,\" they say, guesturing towards a metal plaque situated between two doors.\nAn amber colored 7-segment clock above the plaque reads 29, then 28, 27, 26. Each second it ticks down by one.")
    print()
    input("Press enter to continue...")
    clear()
    print("\"Once that timer hits zero, we need to go through those doors. The timer will start counting again, leaving us with a limited time to escape this dungeon before the curse that has been placed on us becomes impossible to reverse.\"")
    print()
    input("Press enter to continue...")
    clear()
    print("Suddenly, the doors open as the clock arrives at zero. The woman pushes you into the doorway on the right before you even have the opportunity to fully parse what they've told you, let alone ask any questions about your current situation.")
    print()
    input("Press enter to continue...")
    clear()
    print("\"Good luck!\" she shouts, as the door locks behind you.")
    print()
    input("Press enter to start!\n\n(Type \"help\" for a list of commands.)")


introduction()
w = World()
r = RoomMaker()
m = MonsterMaker()
w.createDungeonOne()
player.getCursed(1) #Remove if more curses are added.
playing = True
inDungeon = True #Curse only progresses while in a dungeon. (This is now redundant, as the game now takes place entirely in the dungeon after the introduction.)
timePassing(1)
while playing and player.alive:
    printSituation()
    commandSuccess = False
    timePasses = False
    while not commandSuccess:
        commandSuccess = True
        command = input("What now? ")
        commandWords = command.split()
        if not command:
            clear()
            print("C'mon, there has to be something that you want to do.")
            input("Press enter to continue...")
        elif commandWords[0].lower() == "go":
            if player.goDirection(commandWords[1]):
                timePasses = True
        elif commandWords[0].lower() == "n": #Shortcuts for north, south, east, west. No text adventure is complete without these.
            if player.goDirection("north"):
                timePasses = True
        elif commandWords[0].lower() == "s":
            if player.goDirection("south"):
                timePasses = True
        elif commandWords[0].lower() == "e":
            if player.goDirection("east"):
                timePasses = True
        elif commandWords[0].lower() == "w":
            if player.goDirection("west"):
                timePasses = True
        elif commandWords[0].lower() == "open":
            player.location.chestState = 0
        elif commandWords[0].lower() == "pickup":  #can handle multi-word objects
            targetName = command[7:]
            target = player.location.getItemByName(targetName)
            if target != False:
                if target.effect[0] == 4:
                    useItem(target)
                else:
                    player.pickup(target)
            else:
                print("No such item.")
                commandSuccess = False
        elif commandWords[0].lower() == "get" or commandWords[0].lower() == "buy":  #Alternative verb for pickup, used in shops.
            targetName = command[4:]
            target = player.location.getItemByName(targetName)
            if target != False:
                if target.effect[0] == 4:
                    useItem(target)
                else:
                    player.pickup(target)
            else:
                print("No such item.")
                commandSuccess = False
        elif commandWords[0].lower() == "inventory" or commandWords[0].lower() == "i": #Not having i would be inexcusable.
            player.showInventory()
        elif commandWords[0].lower() == "help":
            showHelp()
        elif commandWords[0].lower() == "puzzle": #Lets the player interact with puzzles.
            r.puzzlePicker()
        elif commandWords[0].lower() == "exit": #quits the game
            playing = False
        elif commandWords[0].lower() == "attack": #Anniying command, honestly. If I weren't already making a GB version, I'd
            targetName = command[7:]
            target = player.location.getMonsterByName(targetName)
            if target != False:
                player.attackMonster(target)
            else:
                clear()
                print("Your efforts to find someone to fight who goes by that name end in disappointment.")
                print()
                input("Press enter to continue...")
                commandSuccess = False
        elif commandWords[0].lower() == "wait":
            timePasses = True #Wait command - basic version
            if len(command) >= 6:
                if int(command[5:]): #Wait command - advanced version
                    timePassing(int(command[5:]))
                    timePasses = False
                else:
                    clear()
                    print("The waiting time needs to be an integer.")
                    print("Let's assume you meant to type \'1\' instead.")
                    input("Press enter to continue...")
        elif commandWords[0].lower() == "unlock": #Command for unlocking doors and the locked chest.
            unlock()
        elif commandWords[0].lower() == "me": #Me command
            player.showMe()
        elif commandWords[0].lower() == "xyzzy": #Cheat code - skip puzzles and combat.
            if player.cheating == 0:
                player.cheating = 1
                clear()
                print("It's cheating time.")
                print()
                input("Press enter to continue...")
            else:
                player.cheating = 0
                clear()
                print("That's enough cheating for now.")
                print()
                input("Press enter to continue...")
        elif commandWords[0].lower() == "map": #Manual map command
            showMap(1) #The 1 adds a clear before printing the map, meaning it will be the onlything shown onscreen.
        elif commandWords[0].lower() == "x" or commandWords[0].lower() == "examine" or commandWords[0].lower() == "inspect": #Examine command
            if commandWords[1]:
                itemTarget = " ".join(commandWords[1:])
                if commandWords[1].lower() == "self" or commandWords[1].lower() == "me" or commandWords[1].lower() == "body" or commandWords[1].lower() == "myself": #If they're looking at themself, just call the me command.
                    player.showMe()
                elif player.location.getItemByName(itemTarget):
                    clear()
                    print(player.location.getItemByName(itemTarget).desc)
                    print()
                    input("Press enter to continue...")
                elif player.getItemByName(itemTarget) != False:
                    clear()
                    print(player.getItemByName(itemTarget).desc)
                    print()
                    input("Press enter to continue...")
                else:
                    clear()
                    print("There isn't any \"" + str(itemTarget) + "\" here. Sorry about that.")
                    print()
                    input("Press enter to continue...")
                    printSituation()
        elif commandWords[0].lower() == "use" or commandWords[0].lower() == "u" or commandWords[0].lower() == "drink" or commandWords[0].lower() == "quaff" or commandWords[0].lower() == "equip" or commandWords[0].lower() == "wear": #Use command
            if commandWords[1]:
                itemTarget = " ".join(commandWords[1:])
                if player.location.getItemByName(itemTarget): #If it's in the room...
                    useItem(player.location.getItemByName(itemTarget))
                elif player.getItemByName(itemTarget): #If it's in the inventory...
                    useItem(player.getItemByName(itemTarget))
                    player.items.remove(player.getItemByName(itemTarget))
                else: #In the event of a typo or non-existant item...
                    clear()
                    print("You don't have a \"" + str(itemTarget) + "\". Sorry about that.")
                    print()
                    input("Press enter to continue...")
        elif commandWords[0].lower() == "retreat": #Retreat, regardless of monsters.
            if player.goDirection("from"):
                timePasses = True
        elif commandWords[0].lower() == "quit": #Quits the game.
            clear()
            print("Are you sure you want to quit?")
            #print("Any progress since your last visit to town will be lost.")
            print()
            player.resume = True
            yesno = input("Y/N: ")
            if yesno.lower() == "y":
                quit()
        #elif commandWords[0].lower() == "save": #Doesn't actually save.
            #clear()
            #print("Nah, not right now. You can save once you're back at the village.")
            #print()
            #player.resume = True
            #input("Press enter to continue...")
        elif commandWords[0].lower() == "history":
            if commandWords[1].lower() == "on":
                def clear():
                    print()
                clear()
                print("History on.")
            elif commandWords[1].lower() == "off":
                def clear():
                    os.system('cls' if os.name == 'nt' else 'clear')
                clear()
                print("History off.")
                print()
                player.resume = True
                input("Press enter to continue...")
            else:
                clear()
                print("Remember, you can turn the history on or off by typing 'history on' or 'history off.'\nJust 'history' doesn't do much.")
                print()
                input("Press enter to continue...")

        else:
            print("Not a valid command")
            commandSuccess = False
    if timePasses == True:
        timePassing(1)
