import os

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

class Item:
    def __init__(self, name, desc, value, effect):
        self.name = name
        self.desc = desc
        self.loc = None
        self.value = value
        self.effect = effect #[type, value] Types are 0: Unuseable, 1: Healing, 2: Weapon, 3: Armor
    def describe(self):
        clear()
        print(self.desc)
        print()
        input("Press enter to continue...")
    def putInRoom(self, room):
        self.loc = room
        room.addItem(self)
