import os

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def go_whence_I_came(direction):
    if direction == "north":
        return "south"
    elif direction == "south":
        return "north"
    elif direction == "east":
        return "west"
    elif direction == "west":
        return "east"

class Player:
    def __init__(self, curse = None, timeSpent = 0, money = 0, experience = 0, progression = 0, bonusAttack = 0, armorRating = 0):
        self.location = None
        self.items = []
        self.health = 50
        self.alive = True
        self.curse = curse #Variable defining which curse the player is afflicted with. ["stage 1", "stage 2", ... "stage 8", "name of curse"]
        self.timeSpent = timeSpent #Ticks up with each movement, progressing the curse.
        #Maybe move timespent to curse object.
        self.money = money #Used to track how much the player has brought back from the dungeon to trade
        self.conditions = []
        self.whence_I_came = None
        self.progression = progression
        self.resume = False
        self.curseStage = timeSpent // 10
        self.experience = experience
        self.bonusAttack = bonusAttack
        self.armorRating = armorRating
        self.cheating = 0
    def goDirection(self, direction):
        if direction in self.location.exitNames(): #This was changed in order to 1. update the map, 2. Stop the player from trying to walk outside the map, and 3. Stop the player from just walking past all the monsters.
            if self.location.monsters == [] or self.cheating == 1:
                self.location.explored = "+"
                self.location = self.location.getDestination(direction)
                self.location.explored = "@"
                self.whence_I_came = go_whence_I_came(direction)
                if self.location.type == "Exit": #This runs when the player finishes the game with the standard ending.
                    clear()
                    print("At last! You emerge from the dungeon, victorious. The sun shines bright above the grassy hill you now find yourself atop, and as the sun hits your body, you can feel the changes slowing, then stopping, and finally begin to reverse.")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("Something feels off about this whole situation though. Why did this even happen to you? Who, or what, benefits from this?\n\nWas there somthing you missed in the dungon?")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("Suddenly, you begin to feel faint and your body slumps to the ground.\nAs your vision darkens, you can feel a hard stone floor beneath your limp body that wasn't there a few seconds ago.")
                    print()
                    self.alive = False
                    input("Press enter to quit.")
                if self.location.type == "Secret": #This runs when the player gets to the secret ending.
                    clear()
                    print("Within the room, a the subtle blue glow of a monitor acts as the only source of light. Silhouetted against it, you see someone sitting in a chair.")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("Suddenly, the room's lights are switched on.\n\n\It's woman who was with you when you woke up! \"Surprise!\" she shouts, before putting on a party hat and blowing into a party horn.")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"You made it!\" she says, walking over to you and offering you a similar --but much smaller-- hat. \"I knew you would. My viewers weren't as confident in you as I was. Like, the *average* bet was on you taking another 10 tries to get in here.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"Well, you're here, and just in time too! Just a few more seconds and I would have needed to reset you again. Oh, but I'm getting ahead of myself. I never even told you my name!\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"I'm XxBunnyDemiGodBunnyxX, and you're on my stream! Say hi to everyone!\" she says, waving at something behind you. Turning, you don't see anyone, but seeing as you're likely speaking with a god, you make an attempt to wave one of your paws in that direction.")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"My generous viewers donated to pick what you'd be turning into as you went through the labyrinth. In the end, the crowd donating souls to make you a kangaroo nearly won, but foxes are always popular.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"Now viewers, get your donation buttons ready! You're going to decide the fate of our little foxy freind here!\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"I'll be returning them to their home dimension no matter what, but it's up to you if the return as a fox, a human, or something in-between, and how much of this they'll remember!\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"Will we let them rememeber everything? Nobody would beleive any of their stories about this, and their attempts to explain what they wnet through would be *very* funny.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"Or, maybe we don't even keep any of their memories of being human intact? That could be pretty good, especially if we send our fox-brained freind back in their human body.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"This one never wins, but c'mon, our participant was a good sport. You could send them back fully restored, as if nothing ever happened.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    #print("\"OOOH! New option! What if we sent them back with no memory of this happening, but we made them involuntarily fall into fox mannerisms occasionally? That'd be great!\"\n\nShe rushes back to the computer to type out the new option, before turning back to you and winking.")
                    #print()
                    #input("Press enter to continue...")
                    #clear()
                    print("Giddily hopping up and down at the computer, she tallies up the donations for each option, before excitedly proclaiming \"We have a winner! They'll be human, with no memory of their experiences here, and oooh... Neat! Everyone will know them as \"Foxy.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"They'll still remember their original name, but when they check their ID... bam! \"Foxy!\" Haha, that'll be great.\" They giggle, turing back to you, winking again.")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\And that's our show! Tune in next week for more shenanigans, with our follower requested theme \"under the sea!\" I love you all!\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("They wave at the invisible audience once more, before turning to you.\n\n\"Don't worry, I'm not going to do any of that. I mean, unless you want me to. I'm a demigod of mischief, but I haven't been that cruel for millennia.")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"Just hop up here and pick your fate. Oh, wait.\" their expression suddenly gets more serious as they continue speaking. \"Please, if someone asks you why you're not named \"Foxy,\" tell them, I dunno, a fairy fixed you or something. Just, cover for me please. They'll stop donating if they think their donations aren't wrecking people's lives in humorous ways.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("\"Okay, yeah. Just hit the number for each option that you want.\"")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("1. Fully human \n2. Anthro fox \n3. Full fox form")
                    print()
                    response = input("SELECT ANSWER: ")
                    if response >= 1 and response <= 3:
                        fateform = response
                        print("INPUT ACCEPTED.\n")
                        input("PRESS ENTER TO CONTINUE.")
                        clear()
                    else:
                        print("ERROR: INVALID INPUT. DEFAULTING TO HUMAN WITH FOX TONGUE\n")
                        fateform = 0
                        input("PRESS ENTER TO CONTINUE.")
                        clear()
                        print("\"What did you type in?! Oh. It deafaulted to the last used setting. Yeah, that's what my followers picked, and you know what? That's the option the last guy stuck with. About this though.... There's no undo button. Sorry?\"")
                        input("Press enter to continue...")
                        clear()
                        print("1. Full memory \n2. No recollection of the show \n3. No recollection of being human")
                        print()
                        response = input("SELECT ANSWER: ")
                        if response >= 1 and response <= 3:
                            fatemind = response
                            print("INPUT ACCEPTED.\n")
                            input("PRESS ENTER TO CONTINUE.")
                            clear()
                        else:
                            print("ERROR: INVALID INPUT. DEFAULTING TO <null>\n")
                            fatemind = 0
                            input("PRESS ENTER TO CONTINUE.")
                            clear()
                            print("\"Uhhh, what? None? There's no undo button on this thing, but I'm definitely not sending you back without a mind. I'll... I'll see wat I can do.\"")
                            print()
                            input("Press enter to continue...")
                            clear()
                    print("As your second selection is confirmed by the computer, colored lights surround you.\nYou begin to feel faint and your body slumps to the ground.")
                    if fatemind == 0:
                        print("Before your vision dims to nothingness, you see \"XxBunnyDemiGodBunnyxX\" activate something on the computer. Colored lights begin swirling around her as well.")
                    print()
                    input("Press enter to continue...")
                    clear()
                    if fatemind == 0:
                        #Mindless ending
                        clear()
                        print("EPILOGUE\n\nSecret Ending 1 - Mindless")
                        print()
                        input("Press enter to continue...")
                        clear()
                        slightdiffSTR = "our body arrived back on Earth without a mind." #This changes the ending a bit based on whether or not they chose to remain human.
                        if fateform != 1:
                            slightdiffSTR = "While it wasn't the only change that your body experienced, y" + slightdiffSTR
                        else:
                            slightdiffSTR = "Y" + slightdiffSTR
                        print(slightdiffSTR + "\nIt wouldn't take too long for your new demigod acquaintance to fix (calling them your \"friend\" would be a bit disingenuous), but it was a bit of a hassle for both of you.")
                        print()
                        input("Press enter to continue...")
                        clear()
                    elif fateform == 0 and fatemind != 3:
                        clear()
                        print("EPILOGUE\n\nSecret Ending 2 - Fox Tounge (Human Mind)")
                        print()
                        input("Press enter to continue...")
                        clear()
                        print("You arrived back on Earth with only one change to your original form, but your new tongue is *very* noticable.\nThis change introduces plenty of new challages into your life, with everything from speaking to drinking being affected.\nWhether you try to find a way to revert this (or, possibly, a partner who's into this) remains to be seen, but life'll be pretty different from here on out.")
                        print()
                        input("Press enter to continue...")
                        clear()
                        #Tongue only ending - human mind
                    elif fateform == 0 and fatemind == 3:
                        clear()
                        print("EPILOGUE\n\nSecret Ending 3 - Fox Tongue (Fox Mind)")
                        print()
                        input("Press enter to continue...")
                        clear()
                        print("When you arrived back on Earth, everything was foriegn to you.\nThe *only part* of your body that feels normal to your foxy mind is your tongue.\nAfter some adjustment though, your new mind quickly realized that this body was significantly more powerful than its old fox body.\nYou'd go on to be a very successful fox, albeit one with a 99% human body.")
                        print()
                        input("Press enter to continue...")
                        clear()
                        #Tounge only ending - fox mind
                    elif fateform == 1:
                        if fatemind == 1:
                            clear()
                            print("EPILOGUE\n\nEnding 1 - Fully Restored")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("You escaped XxBunnyDemiGodBunnyxX's stream, body and mind intact! You might need to deal with another demi-god at some point in the future, but you'll cross that bridge when and if you come to it. For now, you can rest easy for a bit.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Human - full memory
                        if fatemind == 2:
                            clear()
                            print("EPILOGUE\n\nEnding 2 - Blissfully Unaware")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("Completely unaware of your dungeon delving adventure, you were returned to the exact moment that you had been snatched away from your day, allowing you to return to whatever you were doing.\nSure, that's a pretty boring ending, but it's definitely a safe one.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Human - unaware
                        if fatemind == 3:
                            clear()
                            print("EPILOGUE\n\nEnding 3 - On All Levels Except Physical")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("When you arrived back on Earth, everything was foriegn to you.\nAfter some adjustment though, your new mind quickly realized that this body was significantly more powerful than its old fox body.\nYou'd go on to be a very successful fox, albeit one with a 99% human body.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Human - fox mind
                    elif fateform == 2:
                        if fatemind == 1:
                            clear()
                            print("EPILOGUE\n\nEnding 4 - Anthro at Last!")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("Your new body is pretty sweet.\nC'mon, you've got a tail, that alone makes everything you went through worth it.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Anthro - full memory
                        if fatemind == 2:
                            clear()
                            print("EPILOGUE\n\nEnding 5 - A Very Surprising Turn of Events!")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("From your perspective, it seems as if you've been inexplicably turned into an anthropomorphic fox.\nHopefully you won't get dissected thanks to this.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Anthro - unaware (surprised!)
                        if fatemind == 3:
                            clear()
                            print("EPILOGUE\n\nEnding 6 - Nothing Changed?")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("You were in for a lot of confusion when you arrived back on Earth.\nSince you don't remember ever being human, the fact that nobody else on the planet looks anything like you is utterly baffling.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Anthro - anthro mind
                    elif fateform == 3:
                        if fatemind == 1:
                            clear()
                            print("EPILOGUE\n\nEnding 7 - Hell Yeah, Fox Time")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("You're a fox, but you've got full access to all of your human memories and kmowledge.\nWhat will you accomplish with your tremendous abilities?")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Fox - full memory (happy)
                        if fatemind == 2:
                            clear()
                            print("EPILOGUE\n\nEnding 8 - Horror Distilled... Being a Fox is Fine, Actually.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("One moment, you're peacefully going about your day, the next, you're trapped in the body of a fox.\nSince you don't remember that this is exactly what you signed up for, this situation is incredibly startling.\nOnce you acclimate to your new situttion, you'll liekly be a very successful fox, thanks to your knowledge of human society.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Fox - terrified
                        if fatemind == 3:
                            clear()
                            print("EPILOGUE\n\nEnding 9 - Very Foxy")
                            print()
                            input("Press enter to continue...")
                            clear()
                            print("You're a normal fox, with everything that entails. You do normal fox things and live out the rest of your life as a fox would.")
                            print()
                            input("Press enter to continue...")
                            clear()
                            #Fox - unaware

                    print("Hey, thanks for playing my game!\nHopefully you enjoyed it, even despite the poorly formatted text.\nI'm considering rewriting this in Twine to fix that, but this game was originally made as a final for a CS course, so Python was my only option.\nMaking it in Twine would also make this playable in a browser, and I'm sure a lot of people would be interested in that.\n")
                    print()
                    input("Press enter to continue...")
                    clear()
                    print("Want to run through the game again? Use the cheat code \"XYZZY\" to bypass combat and instantly complete puzzles!\n\nFollow me on Itch.io!\n\nI'll definitely be making more, better, games in the future.")
                    print()
                    input("Press enter to exit!")
                return True
            elif self.location.puzzleState == 1:
                clear()
                print("All of the exits are sealed!")
                print("You're going to need to complete that puzzle if you want to escape.")
                print()
                input("Press enter to continue...")
                return False
            else:
                clear()
                print("You can't make it past the monsters in this room without being noticed.") #In the event that there are still monsters here, print this message.
                print()
                input("Press enter to continue...")
                return False
        elif direction == "from" or direction == "back" or direction == "whence": #Allows the player to retreat even if there is a monster, and also allows for the player to say "go whence I came" just like in Limmy's Show.
            if self.whence_I_came:
                return self.goDirection(self.whence_I_came)
            else:
                clear()
                print("There's no going back now.")
                print()
                input("Press enter to continue...")
                return False
        else:
            clear()
            print("There's no exit in that direction.") #In the event there is no room that way, print this message.
            print()
            input("Press enter to continue...")
            return False #Stops the clock from ticking up when the player hasn't actually moved.
    def pickup(self, item):
        if self.location.shop == 0:
            self.items.append(item)
            item.loc = self
            self.location.removeItem(item)
        else:
            if self.money >= item.value:
                clear()
                self.money -= item.value
                self.items.append(item)
                item.loc = self
                self.location.removeItem(item)
                print("You now have " + str(self.money) + " coins.")
                print()
                input("Press enter to continue...")
            else:
                clear()
                print("You don't have enough money!")
                print()
                input("Press enter to continue...")
    def showInventory(self):
        clear()
        print("You are currently carrying:")
        print()
        if len(self.items) > 0:
            for i in self.items:
                print(i.name) # + ", worth " + str(i.value) + " units of currency"
        else:
            print("Nothing.")
        print()
        input("Press enter to continue...")
    def tradeItems(self): #UNUSED
        invValue = 0
        if len(self.items) > 0:
            for i in self.items:
                invValue += i.value
            self.money += invValue
            self.items = []
            print("Together, the items you gathered were worth " + str(invValue) + ".\n\nThat brings you up to " + str(self.money) + ".")
            input("Press enter to continue...")
        else:
            print("Sorry, you don't have anything to trade right now.")
    def attackMonster(self, mon):
        clear()
        print("You are attacking " + mon.name)
        print()
        print("Your health is " + str(self.health) + ".")
        print(mon.name + "'s health is " + str(mon.health) + ".")
        print()
        if self.health > (mon.health - self.bonusAttack - self.armorRating):
            self.health -= (mon.health - self.bonusAttack - self.armorRating)
            print("You win. Your health is now " + str(self.health) + ".")
            mon.die()
        else:
            clear()
            print("You've lost the battle, and with it, any hope of successfully escaping.\nAs your vision fades you know that if you wake up again, you aren't going to be doing so as a human.")
            self.alive = False #Not neccissarily....
        print()
        input("Press enter to continue...")
    def showMe(self):
        clear()
        print("Your health:\n" + str(self.health))
        print()
        print("Time reamaining:\n" + str(80 - self.timeSpent)) #To do: Edit number for expected length of game in turns here, possibly change to self.curse.timespent?
        print()
        print("Curse:\n" + str(self.curse[9]))
        print()
        print("Description:\n" + self.curse[self.curseStage]) #Description from curse object to be implemented
        print()
        print("Conditions:")
        for i in self.conditions:
            print(i)
        print()
        input("Press enter to continue...")
    def getItemByName(self, name):
        for i in self.items:
            if i.name.lower() == name.lower():
                return i
    def fullyTransformed(self):
        clear()
        print("Well, that's it then. The subtle feeling of the curse gradually re-writing your existence is fading away, and with it, any chance of escaping before it overtakes you entirely. What happens now is uncertain, but one thing is for sure. Whatever you do now, you will be doing it as a " + self.curse[9].lower() + ".")
        print()
        self.alive = False
        input("Press enter to continue...")
    def getCursed(self, curseIndex):
        if curseIndex == 1:
            #Fox
            self.curse = ["You're looking like you always have. That might not be the case for long though.", "While you are otherwise human in appearance, the fuzzy ears atop your head are a concrete reminder that you will need to move quickly if you want to leave as anything but a fox.\nThe ears are kinda cute, but the transformation really messed with your inner ear for a bit.", "First the ears, now a tail? What's next?\nWell, whatever form the next step takes, it certainly won't be making you look any more human.", "If you can lift the curse, you might return to normal, but if you don't, at least you can look forward to being very popular with furries...\n...well... You would if it weren't for your face. You'd have a pretty easy time getting cast in \"Cats\" though. Or, you could be vivisected as soon as you're out of here, but it's probably not a good idea to think about that.", "What a relief. Can you imagine how creepy you would have looked if your face changed last? You'd be like one of those paintings of animals where the artist has clearly only ever painted human faces.\nYou're looking pretty \"foxy\" right now, what with the ears, tail, muzzle, and fur.", "Paws? Couldn't they have taken just a bit longer to come in? Not having thumbs would make most things harder under noraml circumstances, but now you're being left without the ability to use your weapons? Ugh.", "What a miniscule change. Digitigrade legs? After such an inconvenient change, you kinda expected something worse. You're nearing the end of your changes though, so you can expect something along those lines very soon.", "You're almost entirely indistinguishable from any other fox now. The hair you had prior to the transformation still sits atop your head, still styled just as it was. Along with that, your eyes still appear more human-like than those of most foxes, but you're definitely more fox than human at this point. Actually, you probably passed that threshold a while ago.", "You're a fox. There is nothing even remotely human left in your appearance. Calling you \"foxy\" at this point would be a dramatic understatement.", "Fox"] #Descriptions when examining the player
            self.curseconditions = ["Unchanged", "Fox ears", "Tail", "Fur", "Muzzle", "Paws", "Digitigrade legs", "All fours", "100% fox"]
            self.curseEvents = ["As you enter the dungeon, you begin to feel the curse's energy flowing throughout your body.", "Suddenly, the world goes completely silent. Dizziness sets in, and it is hard to hold yourself up. After a few seconds have passed you begin to hear your surroundings again. For a few more seconds, your surroundings are muffled, as if your head were underwater. As suddenly as it started, your hearing returns. Whatever was blocking it is gone, but something is different. The sounds coming from in front of you sound much louder than how they did before. Something has obviously changed.\nRegaining your balance, you hold your head as the dizziness subsides, suddenly realizing what has happened as you feel two new fuzzzy triangles atop your head.\nIndeed, your previously human ears have been completely replaced. Where they once were, two fox ears have taken their place.\n\nGreat.", "Unlike the previous change, when this one starts, it is immediately obvious what's happening. In the words of the beloved 90's platformer hero Gex, \"it's tail time.\" Rapidly springing forth from the base of your spine, the large, fluffy tail emerges from beneath your clothing. Thankfully, this change isn't accomapnied by any major discomfort, just lots and lots of new vertebrae, some muscle to move it around with, and plenty of very fluffy fur.", "Your transformation is progressing again. Pins and needles emanate from the base of your spine, quickly rising up along it, before spreading out towards your extremities. Yep, that's fur, and just as expected, it's orange. As it spreads to your hands (and presumably your feet as well), the orange is replaced by black. You assume that the fur on your chest and neck is white, but you really don't have time to check. As soon as this batch of changes stops, you really need to get back to progressing through the dungeon.", "The changes are starting again. A force presses in around your nose and chin, almost as if a ghostly hand is holding your mouth shut. This force then begins to pull away from your face, and your face pulls along with it. Since, by this point, it's obvious what you're turning into, the new wetness of your vulpine nose isn't as surprising as the ears were. While you wouldn't usually notice your nose, thanks to the fact that your new muzzle takes up so much of your field of view, it's much harder to ignore.", "The weapon you were holding just a second ago clatters to the ground as you lose your grip on it. Looking down, it quickly becomes apparent why. Where you once sported prehensile hands with opposable thumbs, only paws remain.\nThis is definitely going to make combat a lot harder.", "You let out an inadvertant yip as your eye level suddenly raises by a few inches. It quickly becomes apparent why, as your legs have become digitigrade.\nThankfully, no, gaining digitigrade legs does not mean that your knees have turned backwards. It's a surprisingly common misconception, but plantigrade and digitigrade legs are usually jointed in the same manner. Your ankles are a lot further from your toes than they were, but your knees are in the exact same position that they were before.\nHaving your knees bend backwards sounds incredibly painful! Thank goodness you're not turning into a bat. An ostrich would be weird too. Four kneecaps? Why would they ever need that many?", "You kind of knew it was coming, but it doesn't make this part any better. Unlike the previous stage of your transformation, this time your point of view is rapidly falling closer and closer to the ground. You're shrinking. More concerningly, you're also dropping down onto your forepaws, becoming quadrupedal.\nYou may still have some of your original features, but this change is a lot to take in.\nTaking a few cautious steps in your new position, it becomes clear that you are not quite comfortable with your new form of locomotion.", "The last of your changes are occuring now. There's nothing that you can observe, but it's clear that something is happening.", "Fox"] #transformation descriptions
            self.sounds = [[''], ['','','','','','','','','','',' *yip* '], ['','','','','','','','','',' *yip* '], ['','','','','','','','','','',' *bark* ',' *yip* '], ['','','','','','','','',' *grr* ',' *bark* ',' *yip* '], ['','','','','','','',' *grr* ',' *bark* ',' *yip* '], ['','','','',' *grr* ',' *bark* ',' *yip* '], ['','',' *grr* ',' *bark* ',' *yip* '], ['',' *grr* ',' *bark* ',' *yip* ']] #Random words that would have been inserted into dialogue with increasing frequency as teh player gets more transformed.
