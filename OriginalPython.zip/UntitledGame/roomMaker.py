import random
import player
'''
class RoomMaker:
    def __init__(self):
        self.dialTurns = random.randint(1200, 1700)
        self.dialOneMaxNumber = random.randint(4,9)
        self.dialTwoMaxNumber = random.randint(4,9)
        while self.dialTwoMaxNumber == self.dialOneMaxNumber:
            self.dialTwoMaxNumber = random.randint(4,9)

        self.dungeonOneStandard = ["Stepping into the room, it's clear that this room is part of the dungeon's sewer system. You start to wonder how exactly that works in a constantly shifting labyrinth, but then you remember that a magical curse is the whole reason you're in this mess. There's no point in trying to figure out how magic sewer systems work right now, you're on a strict time limit. Nevertheless, your internal counter for how many times you've been forced to explore a sewer ticks up by one.", "As far as architecture goes, this room has basically no defining features. It's somehow blander than an expired matzah cracker.", "The massive stone walls in this room seem to stretch up forever.", "There is an etching on the floor of this room. It reads \"This room doesn't contain any traps, but you need to stay on your toes for when one does!\"", "Each of the four walls of this room feature what appears to be an  intricate stained glass window. Light pours into the room from each of them, projecting their designs onto the floor, but upon closer inspection, the windows are actually emitting their own light, and there is no way to break through them and enter into another room."]
        random.shuffle(self.dungeonOneStandard)
        self.dungeonOnePuzzle = ["A stone pedestal stands in the center of this room. On it are two dials. The first has nothces numbered 0-" + str(self.dialOneMaxNumber - 1) + ", \nand the second has the numbers 0-" + str(self.dialTwoMaxNumber - 1) +". \nA note next to them reads 'Starting with both dials set to  0, just turn each one " + str(self.dialTurns) + " notches, and you'll be out of here in no time.\n \nIn a room containing a puzzle, you can attempt to solve it by typing 'puzzle.''", "Kings's Quest puzzle BS"]
        random.shuffle(self.dungeonOnePuzzle)
        self.dungeonOneAnnoyance = ["\'tis a dead end.", "Oh, good. You're glad that completing that puzzle is leading to somewhere useful instead of just a dead end or something. It would be extremely frustrating if a puzzle like that didn't lead to meaningful progression through the dungeon."]
        random.shuffle(self.dungeonOneAnnoyance)
    def dungeonOneDialPuzzle(self):
        print()
        solved = False
        while solved == False:
            print("What position do you set the first dial to?")
            d1 = input()
            print("How about the second one?")
            d2 = input()
            if d1 == self.dialTurns % self.dialOneMaxNumber and d2 == self.dialTurns % self.dialTwoMaxNumber:
                print("The two dials click into place, as the walls in front of you open to reveal a new exit.")
            else:
                print("It doesn't seem like that's the solution.")
                #TIME PASSES

    def dungeonOneNamePuzzle(self):
        print()

    def puzzlePicker(self):
        if player.location.desc[:15] == "A stone pedestal":
            self.dungeonOneDialPuzzle()
        else:
            print("There's no puzzle in this room.")
            print()
            input("Press enter to continue...")
'''
